
package view;
//classe da tela principal:

import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableRowSorter;

//classe principal:
public class Principal extends javax.swing.JFrame {

    public Principal() {
       
        initComponents();
        
      // abrido o programa no centro da tela  
        setLocationRelativeTo(null);
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jdpprincipal = new javax.swing.JDesktopPane();
        jMenuBar1 = new javax.swing.JMenuBar();
        jMenu1 = new javax.swing.JMenu();
        jButtonFornCadastro = new javax.swing.JRadioButtonMenuItem();
        jButtonTransCadastro = new javax.swing.JRadioButtonMenuItem();
        jButtonSetorCadastro = new javax.swing.JRadioButtonMenuItem();
        jMenu2 = new javax.swing.JMenu();
        ButtonEntradaItem = new javax.swing.JRadioButtonMenuItem();
        ButtonSaidaItem = new javax.swing.JRadioButtonMenuItem();
        jMenu3 = new javax.swing.JMenu();
        ButtonMenuFechar = new javax.swing.JRadioButtonMenuItem();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(null);

        jdpprincipal.setBackground(new java.awt.Color(153, 153, 255));
        jdpprincipal.setForeground(new java.awt.Color(0, 0, 0));

        javax.swing.GroupLayout jdpprincipalLayout = new javax.swing.GroupLayout(jdpprincipal);
        jdpprincipal.setLayout(jdpprincipalLayout);
        jdpprincipalLayout.setHorizontalGroup(
            jdpprincipalLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 890, Short.MAX_VALUE)
        );
        jdpprincipalLayout.setVerticalGroup(
            jdpprincipalLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 630, Short.MAX_VALUE)
        );

        getContentPane().add(jdpprincipal);
        jdpprincipal.setBounds(0, 0, 890, 630);

        jMenuBar1.setBackground(new java.awt.Color(255, 255, 255));
        jMenuBar1.setToolTipText("");

        jMenu1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagens/add.png"))); // NOI18N
        jMenu1.setText("Cadastro");
        jMenu1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenu1ActionPerformed(evt);
            }
        });

        jButtonFornCadastro.setSelected(true);
        jButtonFornCadastro.setText("Fornecedor");
        jButtonFornCadastro.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonFornCadastroActionPerformed(evt);
            }
        });
        jMenu1.add(jButtonFornCadastro);

        jButtonTransCadastro.setSelected(true);
        jButtonTransCadastro.setText("Transportadora");
        jButtonTransCadastro.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonTransCadastroActionPerformed(evt);
            }
        });
        jMenu1.add(jButtonTransCadastro);

        jButtonSetorCadastro.setSelected(true);
        jButtonSetorCadastro.setText("Setor");
        jButtonSetorCadastro.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonSetorCadastroActionPerformed(evt);
            }
        });
        jMenu1.add(jButtonSetorCadastro);

        jMenuBar1.add(jMenu1);

        jMenu2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagens/add.png"))); // NOI18N
        jMenu2.setText("Produtos");
        jMenu2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenu2ActionPerformed(evt);
            }
        });

        ButtonEntradaItem.setSelected(true);
        ButtonEntradaItem.setText("Cadastrar Item Entrada");
        ButtonEntradaItem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ButtonEntradaItemActionPerformed(evt);
            }
        });
        jMenu2.add(ButtonEntradaItem);

        ButtonSaidaItem.setSelected(true);
        ButtonSaidaItem.setText("Cadastrar Item Saída");
        ButtonSaidaItem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ButtonSaidaItemActionPerformed(evt);
            }
        });
        jMenu2.add(ButtonSaidaItem);

        jMenuBar1.add(jMenu2);

        jMenu3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagens/cancel.png"))); // NOI18N
        jMenu3.setText("Sair");

        ButtonMenuFechar.setSelected(true);
        ButtonMenuFechar.setText("Fechar");
        ButtonMenuFechar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ButtonMenuFecharActionPerformed(evt);
            }
        });
        jMenu3.add(ButtonMenuFechar);

        jMenuBar1.add(jMenu3);

        setJMenuBar(jMenuBar1);

        setBounds(0, 0, 884, 692);
    }// </editor-fold>//GEN-END:initComponents

    //açao do botao de cadastro dos Itens de Entrada:
    private void ButtonEntradaItemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ButtonEntradaItemActionPerformed
       
       
       EntradaItem obj=new EntradaItem();
       jdpprincipal.add(obj);
       obj.setVisible(true);
       
    }//GEN-LAST:event_ButtonEntradaItemActionPerformed

    private void jMenu2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenu2ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jMenu2ActionPerformed

// açao do botao de cadastro dos Itens de Saída:
    private void ButtonSaidaItemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ButtonSaidaItemActionPerformed
            
       SaidaItem obj=new SaidaItem();
       jdpprincipal.add(obj);
       obj.setVisible(true);
    }//GEN-LAST:event_ButtonSaidaItemActionPerformed

        // açao do botao de fechar o sistema:
    private void ButtonMenuFecharActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ButtonMenuFecharActionPerformed

        System.exit(0);
        
    }//GEN-LAST:event_ButtonMenuFecharActionPerformed

    private void jMenu1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenu1ActionPerformed

    }//GEN-LAST:event_jMenu1ActionPerformed

     // açao do botao de cadastro de Setor:
    private void jButtonSetorCadastroActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonSetorCadastroActionPerformed
       
        SetorCadastro obj=new SetorCadastro();
        jdpprincipal.add(obj);
        obj.setVisible(true);
    }//GEN-LAST:event_jButtonSetorCadastroActionPerformed

    // açao do botao de cadastro de Transportadoras:
    private void jButtonTransCadastroActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonTransCadastroActionPerformed
        
        TransCadastro obj=new TransCadastro();
        jdpprincipal.add(obj);
        obj.setVisible(true);

    }//GEN-LAST:event_jButtonTransCadastroActionPerformed

// açao do botao de Cadastro de Fornecedores:
    private void jButtonFornCadastroActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonFornCadastroActionPerformed
        
        FornCadastro obj=new FornCadastro();
        jdpprincipal.add(obj);
        obj.setVisible(true);
    }//GEN-LAST:event_jButtonFornCadastroActionPerformed

    public static void main(String args[]) {
        
        java.awt.EventQueue.invokeLater(() -> {
            new Principal().setVisible(true);
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JRadioButtonMenuItem ButtonEntradaItem;
    private javax.swing.JRadioButtonMenuItem ButtonMenuFechar;
    private javax.swing.JRadioButtonMenuItem ButtonSaidaItem;
    private javax.swing.JRadioButtonMenuItem jButtonFornCadastro;
    private javax.swing.JRadioButtonMenuItem jButtonSetorCadastro;
    private javax.swing.JRadioButtonMenuItem jButtonTransCadastro;
    private javax.swing.JMenu jMenu1;
    private javax.swing.JMenu jMenu2;
    private javax.swing.JMenu jMenu3;
    private javax.swing.JMenuBar jMenuBar1;
    private javax.swing.JDesktopPane jdpprincipal;
    // End of variables declaration//GEN-END:variables
}
