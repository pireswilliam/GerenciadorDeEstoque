package view;

import Model.bean.Fornecedor;
import Controller.FornecedorDAO;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableRowSorter;

//classe para cadastro de fornecedores:
public class FornCadastro extends javax.swing.JInternalFrame {
      
    
    public FornCadastro() {
        
        initComponents();
        
        DefaultTableModel modelo = (DefaultTableModel)jTableForn.getModel();
        jTableForn.setRowSorter(new TableRowSorter(modelo));
        readTable();
        
        ManipulaInterfaceForn("Navegar");   
    }
    
    // ler e carregar os dados na tabela interface
    public void readTable(){
     DefaultTableModel modelo = (DefaultTableModel)jTableForn.getModel();
     modelo.setNumRows(0);
     FornecedorDAO fdao = new FornecedorDAO();
     
     for(Fornecedor f: fdao.read()){
         modelo.addRow(new Object[]{
             f.getForn_codigo(),
             f.getForn_nome(),
             f.getForn_cep(),
             f.getForn_rua(),
             f.getForn_numero(),
             f.getForn_cidade (),
             f.getForn_telefone (),
         });
     }
    }
        // ação dos botões de novo, alterar, remover
        // bloquear e desbloquear as sequencias de ordens dos botões com as respectivas ação realizadas
     public void ManipulaInterfaceForn (String modo){
             switch (modo){
               case "Navegar":
                forn_codigo.setEnabled(false);
                jButtonNovo.setEnabled(true);
                jButtonSalvar.setEnabled(true);
                jButtonAlterar.setEnabled(false);
                jButtonRemover.setEnabled(false);
                break;
            
                case "Novo":
                forn_codigo.setEnabled(false);
                jButtonNovo.setEnabled(false);
                jButtonSalvar.setEnabled(true);
                jButtonAlterar.setEnabled(false);
                jButtonRemover.setEnabled(false);
                  
              break; 
              
           case "Alterar":
              forn_codigo.setEnabled(false);
              jButtonNovo.setEnabled(true);
              jButtonSalvar.setEnabled(false);
              jButtonAlterar.setEnabled(true);
              jButtonRemover.setEnabled(true);       
               
               break;
                   
           case "Remover":
              forn_codigo.setEnabled(false);
              jButtonNovo.setEnabled(true);
              jButtonSalvar.setEnabled(false);
              jButtonAlterar.setEnabled(true);
              jButtonRemover.setEnabled(true);
               break;
           default: System.out.println("Modo Inválido ");        
           }

    }
 
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane1 = new javax.swing.JScrollPane();
        jTextArea1 = new javax.swing.JTextArea();
        jPanelDadosForn = new javax.swing.JPanel();
        forn_nome = new javax.swing.JTextField();
        jLabelNome = new javax.swing.JLabel();
        forn_cep = new javax.swing.JFormattedTextField();
        jLabelCep = new javax.swing.JLabel();
        forn_rua = new javax.swing.JTextField();
        jLabelRua = new javax.swing.JLabel();
        forn_cidade = new javax.swing.JTextField();
        jLabelCid = new javax.swing.JLabel();
        forn_telefone = new javax.swing.JFormattedTextField();
        jLabelTel1 = new javax.swing.JLabel();
        jButtonSalvar = new javax.swing.JButton();
        jButtonAlterar = new javax.swing.JButton();
        jButtonRemover = new javax.swing.JButton();
        jButtonNovo = new javax.swing.JButton();
        jLabelNum = new javax.swing.JLabel();
        forn_numero = new javax.swing.JFormattedTextField();
        forn_codigo = new javax.swing.JTextField();
        jLabel1 = new javax.swing.JLabel();
        jSeparator1 = new javax.swing.JSeparator();
        jPanelFornCad = new javax.swing.JPanel();
        jScrollPane2 = new javax.swing.JScrollPane();
        jTableForn = new javax.swing.JTable();

        jTextArea1.setColumns(20);
        jTextArea1.setRows(5);
        jScrollPane1.setViewportView(jTextArea1);

        setClosable(true);
        setIconifiable(true);
        setMaximizable(true);
        setTitle("Cadastro Fornecedor");

        jPanelDadosForn.setBackground(new java.awt.Color(153, 153, 255));
        jPanelDadosForn.setBorder(javax.swing.BorderFactory.createTitledBorder("Dados do Fornecedor"));

        forn_nome.setBackground(new java.awt.Color(204, 204, 255));
        forn_nome.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                forn_nomeActionPerformed(evt);
            }
        });

        jLabelNome.setText("Nome");

        forn_cep.setBackground(new java.awt.Color(204, 204, 255));
        try {
            forn_cep.setFormatterFactory(new javax.swing.text.DefaultFormatterFactory(new javax.swing.text.MaskFormatter("########")));
        } catch (java.text.ParseException ex) {
            ex.printStackTrace();
        }

        jLabelCep.setText("CEP");

        forn_rua.setBackground(new java.awt.Color(204, 204, 255));

        jLabelRua.setText("Rua");

        forn_cidade.setBackground(new java.awt.Color(204, 204, 255));

        jLabelCid.setText("Cidade");

        forn_telefone.setBackground(new java.awt.Color(204, 204, 255));
        try {
            forn_telefone.setFormatterFactory(new javax.swing.text.DefaultFormatterFactory(new javax.swing.text.MaskFormatter("########")));
        } catch (java.text.ParseException ex) {
            ex.printStackTrace();
        }

        jLabelTel1.setText("Telefone");

        jButtonSalvar.setBackground(new java.awt.Color(204, 204, 255));
        jButtonSalvar.setText("Salvar");
        jButtonSalvar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonSalvarActionPerformed(evt);
            }
        });

        jButtonAlterar.setBackground(new java.awt.Color(204, 204, 255));
        jButtonAlterar.setText("Alterar");
        jButtonAlterar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonAlterarActionPerformed(evt);
            }
        });

        jButtonRemover.setBackground(new java.awt.Color(204, 204, 255));
        jButtonRemover.setText("Remover");
        jButtonRemover.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonRemoverActionPerformed(evt);
            }
        });

        jButtonNovo.setText("Novo");
        jButtonNovo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonNovoActionPerformed(evt);
            }
        });

        jLabelNum.setText("Numero");

        forn_numero.setBackground(new java.awt.Color(204, 204, 255));
        forn_numero.setFormatterFactory(new javax.swing.text.DefaultFormatterFactory(new javax.swing.text.NumberFormatter()));

        forn_codigo.setBackground(new java.awt.Color(204, 204, 255));

        jLabel1.setText("Codigo Fornecedor");

        javax.swing.GroupLayout jPanelDadosFornLayout = new javax.swing.GroupLayout(jPanelDadosForn);
        jPanelDadosForn.setLayout(jPanelDadosFornLayout);
        jPanelDadosFornLayout.setHorizontalGroup(
            jPanelDadosFornLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanelDadosFornLayout.createSequentialGroup()
                .addGroup(jPanelDadosFornLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanelDadosFornLayout.createSequentialGroup()
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jButtonNovo)
                        .addGap(18, 18, 18)
                        .addComponent(jButtonSalvar))
                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanelDadosFornLayout.createSequentialGroup()
                        .addGroup(jPanelDadosFornLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(forn_cep, javax.swing.GroupLayout.PREFERRED_SIZE, 71, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabelCep)
                            .addComponent(jLabelTel1)
                            .addComponent(forn_telefone, javax.swing.GroupLayout.PREFERRED_SIZE, 105, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(28, 28, 28)
                        .addGroup(jPanelDadosFornLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(forn_rua, javax.swing.GroupLayout.PREFERRED_SIZE, 216, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabelRua))
                        .addGap(50, 50, 50)
                        .addGroup(jPanelDadosFornLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(jLabelNum, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(forn_numero))
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addGroup(jPanelDadosFornLayout.createSequentialGroup()
                        .addGroup(jPanelDadosFornLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel1)
                            .addComponent(forn_codigo, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(jPanelDadosFornLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabelNome)
                            .addComponent(forn_nome, javax.swing.GroupLayout.PREFERRED_SIZE, 349, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanelDadosFornLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(forn_cidade, javax.swing.GroupLayout.PREFERRED_SIZE, 182, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanelDadosFornLayout.createSequentialGroup()
                        .addGap(8, 8, 8)
                        .addComponent(jButtonAlterar)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jButtonRemover))
                    .addComponent(jLabelCid))
                .addGap(16, 16, 16))
        );
        jPanelDadosFornLayout.setVerticalGroup(
            jPanelDadosFornLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanelDadosFornLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanelDadosFornLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabelNome)
                    .addComponent(jLabel1))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanelDadosFornLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(forn_nome, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(forn_codigo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanelDadosFornLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabelCep)
                    .addComponent(jLabelRua)
                    .addComponent(jLabelCid)
                    .addComponent(jLabelNum))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanelDadosFornLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(forn_cep, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(forn_rua, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(forn_cidade, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(forn_numero, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addComponent(jLabelTel1)
                .addGap(4, 4, 4)
                .addComponent(forn_telefone, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanelDadosFornLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jButtonSalvar)
                    .addComponent(jButtonAlterar)
                    .addComponent(jButtonRemover)
                    .addComponent(jButtonNovo))
                .addContainerGap(12, Short.MAX_VALUE))
        );

        jPanelFornCad.setBorder(javax.swing.BorderFactory.createTitledBorder("Fornecedores:"));

        jTableForn.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Codigo Fornecedor", "Nome", "Cep", "Rua", "Numero", "Cidade", "Telefone"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jTableForn.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jTableFornMouseClicked(evt);
            }
        });
        jTableForn.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                jTableFornKeyReleased(evt);
            }
        });
        jScrollPane2.setViewportView(jTableForn);

        javax.swing.GroupLayout jPanelFornCadLayout = new javax.swing.GroupLayout(jPanelFornCad);
        jPanelFornCad.setLayout(jPanelFornCadLayout);
        jPanelFornCadLayout.setHorizontalGroup(
            jPanelFornCadLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanelFornCadLayout.createSequentialGroup()
                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 831, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );
        jPanelFornCadLayout.setVerticalGroup(
            jPanelFornCadLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanelFornCadLayout.createSequentialGroup()
                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 277, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 172, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jPanelDadosForn, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jSeparator1)
                    .addComponent(jPanelFornCad, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanelDadosForn, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(50, 50, 50)
                .addComponent(jSeparator1, javax.swing.GroupLayout.PREFERRED_SIZE, 10, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanelFornCad, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        setBounds(0, 0, 870, 630);
    }// </editor-fold>//GEN-END:initComponents

    private void forn_nomeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_forn_nomeActionPerformed
        
    }//GEN-LAST:event_forn_nomeActionPerformed

    // Botão para salvar os dados do fornecedor:
    private void jButtonSalvarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonSalvarActionPerformed
        try {
            
            Fornecedor f = new Fornecedor();
            FornecedorDAO DAO = new FornecedorDAO();
 
            f.setForn_nome(forn_nome.getText());
            f.setForn_cep(Integer.parseInt(forn_cep.getText()));
            f.setForn_rua(forn_rua.getText());
            f.setForn_numero(Integer.parseInt(forn_numero.getText()));
            f.setForn_cidade(forn_cidade.getText());
            f.setForn_telefone(Integer.parseInt(forn_telefone.getText()));
            DAO.create(f);
            readTable();

            {
            }
        } catch (SQLException ex) {
            Logger.getLogger(FornCadastro.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_jButtonSalvarActionPerformed

    // botão de alterar os dados do fornecedor:
    private void jButtonAlterarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonAlterarActionPerformed
        
        if(jTableForn.getSelectedRow()!= -1){

            Fornecedor f = new Fornecedor();
            FornecedorDAO DAO = new FornecedorDAO();
 
            f.setForn_nome(forn_nome.getText());
            f.setForn_cep(Integer.parseInt(forn_cep.getText()));
            f.setForn_rua(forn_rua.getText());
            f.setForn_numero(Integer.parseInt(forn_numero.getText()));
            f.setForn_cidade(forn_cidade.getText());
            f.setForn_telefone(Integer.parseInt(forn_telefone.getText()));
            f.setForn_codigo((int)jTableForn.getValueAt(jTableForn.getSelectedRow(), 0));
            try {
                DAO.update(f);
                
            } catch (SQLException ex) {
                Logger.getLogger(FornCadastro.class.getName()).log(Level.SEVERE, null, ex);
            }
            readTable();
            }else{
            JOptionPane.showMessageDialog(null, "Selecione um Fornecedor para Alterar.");
        }{
         }
        readTable();
    }//GEN-LAST:event_jButtonAlterarActionPerformed
    
    // botao de remover os dados do fornecedor:
    private void jButtonRemoverActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonRemoverActionPerformed
        
        
        if (jTableForn.getSelectedRow()!= -1) {
            
            Fornecedor f = new Fornecedor();
            FornecedorDAO DAO = new FornecedorDAO();
 
            f.setForn_codigo((int)jTableForn.getValueAt(jTableForn.getSelectedRow(), 0));
            try {
                DAO.delete(f);
                
            } catch (SQLException ex) {
                Logger.getLogger(FornCadastro.class.getName()).log(Level.SEVERE, null, ex);
            }
            
            }else{
            JOptionPane.showMessageDialog(null, "Selecione um Fornecedor para Excluir.");          
        }{
         }
        readTable();
    }//GEN-LAST:event_jButtonRemoverActionPerformed
     
     // botao de limpar os dados de cadastro do fornecedor:
    private void jButtonNovoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonNovoActionPerformed
        
        
        forn_nome.setText("");
        forn_cep.setText("");
        forn_rua.setText("");
        forn_numero.setText("");
        forn_cidade.setText("");
        forn_telefone.setText("");
        
       
        ManipulaInterfaceForn("Novo");      
    }//GEN-LAST:event_jButtonNovoActionPerformed

    // Seleciona com o mouse o campo que deseja fazer as ações: alterar ou remover dados:
    private void jTableFornMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTableFornMouseClicked

            if (jTableForn.getSelectedRow()!= -1){
            forn_codigo.setText(jTableForn.getValueAt(jTableForn.getSelectedRow(), 0).toString());
            forn_nome.setText(jTableForn.getValueAt(jTableForn.getSelectedRow(), 1).toString());
            forn_cep.setText(jTableForn.getValueAt(jTableForn.getSelectedRow(), 2).toString());
            forn_rua.setText(jTableForn.getValueAt(jTableForn.getSelectedRow(),3).toString());
            forn_numero.setText(jTableForn.getValueAt(jTableForn.getSelectedRow(), 4).toString());
            forn_cidade.setText(jTableForn.getValueAt(jTableForn.getSelectedRow(), 5).toString());
            forn_telefone.setText(jTableForn.getValueAt(jTableForn.getSelectedRow(), 6).toString()); 
        }
        ManipulaInterfaceForn("Remover");
        ManipulaInterfaceForn("Alterar");
    }//GEN-LAST:event_jTableFornMouseClicked

    // fazer a alteração dos dados da tabela :
    private void jTableFornKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jTableFornKeyReleased
        

            forn_nome.setText(jTableForn.getValueAt(jTableForn.getSelectedRow(), 1).toString());
            forn_cep.setText(jTableForn.getValueAt(jTableForn.getSelectedRow(), 2).toString());
            forn_rua.setText(jTableForn.getValueAt(jTableForn.getSelectedRow(),3).toString());
            forn_numero.setText(jTableForn.getValueAt(jTableForn.getSelectedRow(), 4).toString());
            forn_cidade.setText(jTableForn.getValueAt(jTableForn.getSelectedRow(), 5).toString());
            forn_telefone.setText(jTableForn.getValueAt(jTableForn.getSelectedRow(), 6).toString());
        
    }//GEN-LAST:event_jTableFornKeyReleased


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JFormattedTextField forn_cep;
    private javax.swing.JTextField forn_cidade;
    private javax.swing.JTextField forn_codigo;
    private javax.swing.JTextField forn_nome;
    private javax.swing.JFormattedTextField forn_numero;
    private javax.swing.JTextField forn_rua;
    private javax.swing.JFormattedTextField forn_telefone;
    private javax.swing.JButton jButtonAlterar;
    private javax.swing.JButton jButtonNovo;
    private javax.swing.JButton jButtonRemover;
    private javax.swing.JButton jButtonSalvar;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabelCep;
    private javax.swing.JLabel jLabelCid;
    private javax.swing.JLabel jLabelNome;
    private javax.swing.JLabel jLabelNum;
    private javax.swing.JLabel jLabelRua;
    private javax.swing.JLabel jLabelTel1;
    private javax.swing.JPanel jPanelDadosForn;
    private javax.swing.JPanel jPanelFornCad;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JSeparator jSeparator1;
    private javax.swing.JTable jTableForn;
    private javax.swing.JTextArea jTextArea1;
    // End of variables declaration//GEN-END:variables
}
