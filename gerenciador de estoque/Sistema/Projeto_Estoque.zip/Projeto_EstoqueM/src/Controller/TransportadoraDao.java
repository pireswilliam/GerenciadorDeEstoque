package Controller;

import Model.bean.Transportadora;
import connection.ConnectionFactory;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;

public class TransportadoraDao {
    
    // ação de inserir os dados diretamento no banco de dados
    public void create (Transportadora t){
    
    Connection con = ConnectionFactory.getConnection();
    PreparedStatement stmt = null;
    
        try {
            stmt = con.prepareStatement("INSERT INTO transportadora (transp_nome, transp_cep, transp_rua, transp_numero, transp_cidade, transp_telefone)VALUES (?,?,?,?,?,?)");
            
            stmt.setString(1,t.getTransp_nome());
            stmt.setInt(2,t.getTransp_cep());
            stmt.setString(3,t.getTransp_rua());
            stmt.setInt(4,t.getTransp_numero());
            stmt.setString(5,t.getTransp_cidade());
            stmt.setInt(6,t.getTransp_telefone());
            
            stmt.executeUpdate();
            
            JOptionPane.showMessageDialog(null, "Salvo com Sucesso ");
                    
            } catch (SQLException ex) {
             JOptionPane.showMessageDialog(null, "Erro ao Salvar"+ ex);
        }finally{
          ConnectionFactory.closeConnection(con, stmt);
        }

    }
    
    // ação de alterar os dados diretamento no banco de dados
    public void update (Transportadora t){
    
    Connection con = ConnectionFactory.getConnection();
    PreparedStatement stmt = null;
    
        try {
            stmt = con.prepareStatement("UPDATE Transportadora SET transp_nome =? , transp_cep= ?, transp_rua= ?, transp_numero= ?, transp_cidade= ?, transp_telefone= ? WHERE transp_codigo = ? ");
            
            stmt.setString(1,t.getTransp_nome());
            stmt.setInt(2,t.getTransp_cep());
            stmt.setString(3,t.getTransp_rua());
            stmt.setInt(4,t.getTransp_numero());
            stmt.setString(5,t.getTransp_cidade());
            stmt.setInt(6,t.getTransp_telefone());
            stmt.setInt(7,t.getTransp_codigo());
                    
            stmt.executeUpdate();
            
            JOptionPane.showMessageDialog(null, "Alterado com Sucesso ");
                    
            } catch (SQLException ex) {
             JOptionPane.showMessageDialog(null, "Erro ao Alterar"+ ex);
        }finally{
          ConnectionFactory.closeConnection(con, stmt);
        }
    
    
    }
    
    // ação de excluir os dados diretamento no banco de dados
    public void delete (Transportadora t){
    
    Connection con = ConnectionFactory.getConnection();
    PreparedStatement stmt = null;
    
        try {
            stmt = con.prepareStatement("DELETE FROM Transportadora WHERE transp_codigo = ? ");     
            stmt.setInt(1,t.getTransp_codigo());    
            stmt.executeUpdate();  
            JOptionPane.showMessageDialog(null, "Removido com Sucesso ");
                    
            } catch (SQLException ex) {
             JOptionPane.showMessageDialog(null, "Erro ao Remover"+ ex);
        }finally{
          ConnectionFactory.closeConnection(con, stmt);
        }

    }
    // listagem das transportadoras cadastradas
    public List<Transportadora> read(){
   
    Connection con = ConnectionFactory.getConnection();
    PreparedStatement stmt = null;
    ResultSet rs = null;
     
       List<Transportadora> Transportadores = new ArrayList<>();
        
       try {
           stmt = con.prepareStatement("SELECT * FROM Transportadora");
           rs = stmt.executeQuery();
           
           while(rs.next()){
                
               Transportadora Transportadora = new Transportadora();
                
                Transportadora.setTransp_codigo(rs.getInt("transp_codigo"));
                Transportadora.setTransp_nome(rs.getString("transp_nome"));
                Transportadora.setTransp_cep(rs.getInt("transp_cep"));
                Transportadora.setTransp_rua(rs.getString("transp_rua"));
                Transportadora.setTransp_numero(rs.getInt("transp_numero"));
                Transportadora.setTransp_cidade(rs.getString("transp_cidade"));
                Transportadora.setTransp_telefone(rs.getInt("transp_telefone"));
                Transportadores.add(Transportadora);
            }
           
       } catch (SQLException ex) {
           Logger.getLogger(TransportadoraDao.class.getName()).log(Level.SEVERE, null, ex);
       }finally{
            ConnectionFactory.closeConnection(con, stmt, rs);
        }
       
     return Transportadores;
       
   }
    
}
