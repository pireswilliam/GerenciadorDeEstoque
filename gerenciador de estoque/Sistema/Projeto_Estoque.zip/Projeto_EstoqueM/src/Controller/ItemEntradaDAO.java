package Controller;

import Model.bean.ItemEntrada;
import connection.ConnectionFactory;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;

public class ItemEntradaDAO {
    // ação de inserir os dados diretamento no banco de dados
    public void create (ItemEntrada IE) throws SQLException{
    
    Connection con = ConnectionFactory.getConnection();
    PreparedStatement stmt = null;
        
        try{
            stmt = con.prepareStatement("INSERT INTO ItemEntrada (itensEnt_nome, itensEnt_data, itensEnt_quantidade, itensEnt_valorCusto)VALUES (?,?,?,?)");
            
            //stmt.setString(1,IE.getItensEnt_nome());
            stmt.setString(1,IE.getItensEnt_nome());
            stmt.setString(2,IE.getItensEnt_data());
            stmt.setInt(3,IE.getItensEnt_quantidade());
            stmt.setDouble(4,IE.getItensEnt_valorCusto());
   
            stmt.executeUpdate();
            
            JOptionPane.showMessageDialog(null, "Salvo com Sucesso ");
                    
            } catch (SQLException ex) {
             JOptionPane.showMessageDialog(null, "Erro ao Salvar"+ ex);
            }finally{
             ConnectionFactory.closeConnection(con, stmt);
            }
    }
    
    // ação de alterar os dados diretamento no banco de dados
    public void update (ItemEntrada IE) throws SQLException{
    
    Connection con = ConnectionFactory.getConnection();
    PreparedStatement stmt = null;
        
        try{
            stmt = con.prepareStatement("UPDATE ItemEntrada SET itensEnt_nome= ?, itensEnt_data =? , itensEnt_quantidade=?, itensEnt_valorCusto =?  WHERE itensEnt_codigo = ?");
            
            stmt.setString(1,IE.getItensEnt_nome());
            stmt.setString(2,IE.getItensEnt_data());
            stmt.setInt(3,IE.getItensEnt_quantidade());
            stmt.setDouble(4,IE.getItensEnt_valorCusto());
            stmt.setInt(5,IE.getItensEnt_codigo());
            
            stmt.executeUpdate();
            
            JOptionPane.showMessageDialog(null, "Alterado com Sucesso ");
                    
            } catch (SQLException ex) {
             JOptionPane.showMessageDialog(null, "Erro ao Alterar"+ ex);
            }finally{
             ConnectionFactory.closeConnection(con, stmt);
            }
    }
    
    // ação de excluir os dados diretamento no banco de dados
    public void delete (ItemEntrada IE) throws SQLException{
    
    Connection con = ConnectionFactory.getConnection();
    PreparedStatement stmt = null;
        
        try{
            stmt = con.prepareStatement("DELETE FROM ItemEntrada WHERE itensEnt_codigo = ?");

            stmt.setInt(1,IE.getItensEnt_codigo());
            stmt.executeUpdate();
            JOptionPane.showMessageDialog(null, "Removido com Sucesso ");
                    
            } catch (SQLException ex) {
             JOptionPane.showMessageDialog(null, "Erro ao Remover"+ ex);
            }finally{
             ConnectionFactory.closeConnection(con, stmt);
            }  
    }
    
    // listagem dos itens entrada cadastrados
    public List<ItemEntrada> read(){
   
    Connection con = ConnectionFactory.getConnection();
    PreparedStatement stmt = null;
    ResultSet rs = null;
     
       List<ItemEntrada> ItensEntrada = new ArrayList<>();
        
       try {
           stmt = con.prepareStatement("SELECT * FROM ItemEntrada");
           rs = stmt.executeQuery();
           
           while(rs.next()){
                
               ItemEntrada ItemEntrada = new ItemEntrada();
                
                ItemEntrada.setItensEnt_codigo(rs.getInt("itensEnt_codigo"));
                ItemEntrada.setItensEnt_nome(rs.getString("itensEnt_nome"));
                ItemEntrada.setItensEnt_data(rs.getString("itensEnt_data"));
                ItemEntrada.setItensEnt_quantidade(rs.getInt("itensEnt_quantidade"));
                ItemEntrada.setItensEnt_valorCusto(rs.getDouble("itensEnt_valorCusto"));
                ItensEntrada.add(ItemEntrada);
            }
           
       } catch (SQLException ex) {
           Logger.getLogger(ItemEntradaDAO.class.getName()).log(Level.SEVERE, null, ex);
       }finally{
            ConnectionFactory.closeConnection(con, stmt, rs);
       }
       
       return ItensEntrada;       
   }

}
