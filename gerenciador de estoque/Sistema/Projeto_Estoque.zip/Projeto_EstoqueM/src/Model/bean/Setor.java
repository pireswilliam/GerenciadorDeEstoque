package Model.bean;

public class Setor {
    // atributos da classe Setor:
    private int setor_codigo;
    private String setor_nome;
    private String setor_descricao;

    // construtores
    public Setor() {
    }

    public Setor(int setor_codigo, String setor_nome, String setor_descricao) {
        
        this.setor_codigo = setor_codigo;
        this.setor_nome = setor_nome;
        this.setor_descricao = setor_descricao;
    }

    // métodos set e get:
    
    public int getSetor_codigo() {
        return setor_codigo;
    }

    public void setSetor_codigo(int setor_codigo) {
        this.setor_codigo = setor_codigo;
    }

    

    public String getSetor_nome() {
        return setor_nome;
    }

    public void setSetor_nome(String setor_nome) {
        this.setor_nome = setor_nome;
    }

    public String getSetor_descricao() {
        return setor_descricao;
    }

    public void setSetor_descricao(String setor_descricao) {
        this.setor_descricao = setor_descricao;
    }
    

    
}
