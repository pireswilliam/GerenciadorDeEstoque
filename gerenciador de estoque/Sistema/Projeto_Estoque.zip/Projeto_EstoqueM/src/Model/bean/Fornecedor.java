package Model.bean;

public class Fornecedor  {
    // atributos da classe Fornecedor
    private int forn_codigo;
    private String forn_nome;
    private int forn_cep;
    private String forn_rua;
    private int forn_numero;
    private String forn_cidade;
    private int forn_telefone;
    
    
    // construtores
    public Fornecedor() {
      
    }

    public Fornecedor(int forn_codigo, String forn_nome, int forn_cep, 
                      String forn_rua, int forn_numero,  String forn_cidade, int forn_telefone) {
        
        this.forn_codigo = forn_codigo;
        this.forn_nome = forn_nome;
        this.forn_cep = forn_cep;
        this.forn_rua = forn_rua;
        this.forn_numero = forn_numero;
        this.forn_cidade = forn_cidade;
        this.forn_telefone = forn_telefone;
    }
    
    // métodos set e get:
    
    public int getForn_codigo() {
        return forn_codigo;
    }

    public void setForn_codigo(int forn_codigo) {
        this.forn_codigo = forn_codigo;
    }

    
    public String getForn_nome() {
        return forn_nome;
    }

    public void setForn_nome(String forn_nome) {
        this.forn_nome = forn_nome;
    }

    public int getForn_cep() {
        return forn_cep;
    }

    public void setForn_cep(int forn_cep) {
        this.forn_cep = forn_cep;
    }

    public String getForn_rua() {
        return forn_rua;
    }

    public void setForn_rua(String forn_rua) {
        this.forn_rua = forn_rua;
    }
    
    public int getForn_numero() {
        return forn_numero;
    }

    public void setForn_numero(int forn_numero) {
        this.forn_numero = forn_numero;
    }

    public String getForn_cidade() {
        return forn_cidade;
    }

    public void setForn_cidade(String forn_cidade) {
        this.forn_cidade = forn_cidade;
    }

    public int getForn_telefone() {
        return forn_telefone;
    }

    public void setForn_telefone(int forn_telefone) {
        this.forn_telefone = forn_telefone;
    }
  
    @Override
    public String toString(){
       return getForn_nome();
    }
}
